package com.project.java_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
